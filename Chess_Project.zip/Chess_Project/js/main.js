$(function(){
    init ();
    console.log("main called");
});

function initfilesrankbrd(){

    var index = 0;
    var file= files.file_a;
    var rank= ranks.rank_1;
    var sq=squares.a1;

    //First we initailize all the array to offboard values
    for(index=0; index<board_squares_num; ++index){
        filesbrd[index]=squares.offboard;
        ranksbrd[index]=squares.offboard;
    }

    //Then we try to initialize the actual board area with the correct values
    for(rank=ranks.rank_1; rank <=ranks.rank_8; ++rank){
        //for each rank we calculate squrare position and file and rank
        for(file=files.file_a;file<files.file_h; ++file){
            sq=file_rank_2sq(file,rank);//function to do position calculation and return
            filesbrd[sq]=file; //relative postion sq gets a file and rank qg a1 b2
            ranksbrd[sq]=rank;
        }


    } 

    console.log(" " + filesbrd[0] + " " + " "+ranksbrd[0]);
    console.log(" " + filesbrd[squares.a1] + " " + " "+ranksbrd[squares.a1]);
    console.log(" " + filesbrd[squares.e8] + " " + " "+ranksbrd[squares.e8]);

}


function init(){

        initfilesrankbrd()
        console.log("init is called");    
}