var gameboard={};//global varaible

gameboard.pieces=new Array(board_squares_num);
gameboard.side= colours.white;
gameboard.fitymove=0;// fity move count to 100 during the game everytime
//a move is made and reset to zero every time pawn is moved or a capture is made
gameboard.hisply=0;//maintans a count of evry move made in the game from the start
gameboard.ply=0;//count made by each player
gameboard.castleperm=0;// reacord castle permition
/*
note 
0001
0010
0100
1000
corespond to  the deceimal in defination catsling bit
*/
gameboard.material=new Array(2);//black or white material pice

