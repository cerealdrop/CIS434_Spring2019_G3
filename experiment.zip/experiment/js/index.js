$(document).ready(function(){

        $(".card").hide();
        $(".card").show(function(){
        var div = $(".card");
        div.animate({height: '400px', opacity: '0.5'},200);
        div.animate({width: '600px', opacity: '0.5'}, 200);
        div.animate({height: '180px', opacity: '1'}, 1000);
        div.animate({width: '400px', opacity: '1'}, 1000);

        });
        
      
    
  });